"use client";

import { Fragment, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useInView } from "framer-motion";
import { ICON_DOT, ICON_PATH } from "./glass/kit";
import { useLanguage } from "../i18n/LanguageContext";

/**
 * An equation that *performs*: each ingredient lights up in turn (the logo's dot "arrives"
 * in it), a signal travels along the track, and when everything is present the PUIUX mark
 * draws itself — a cradle that holds the dot — as the result. Then it breathes and replays.
 */
export function PartnerEquation() {
  const { t, dir } = useLanguage();
  const parts = t.partner.equationParts;
  const total = parts.length + 1;
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { amount: 0.4 });
  const [step, setStep] = useState(-1);

  useEffect(() => {
    if (!inView) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduced) {
      setStep(total - 1);
      return;
    }
    const id = setTimeout(
      () => setStep((s) => (s >= total - 1 ? -1 : s + 1)),
      step === -1 ? 700 : step >= total - 1 ? 4200 : 1250
    );
    return () => clearTimeout(id);
  }, [inView, step, total]);

  const lit = (i: number) => step >= i;
  const done = step >= total - 1;
  const progress = Math.max(0, Math.min(1, (step + 1) / total));
  const rtl = dir === "rtl";

  return (
    <div
      ref={ref}
      className="relative overflow-hidden rounded-[2rem] bg-[#070707] p-6 text-white shadow-[0_40px_90px_-40px_rgba(0,0,0,0.7)] ring-1 ring-black sm:p-10"
    >
      {/* glass sheen + blur shapes inside the card */}
      <motion.span
        aria-hidden
        className="pointer-events-none absolute -top-24 h-72 w-72 rounded-full bg-white/[0.09] blur-3xl"
        style={{ insetInlineEnd: "-4rem" }}
        animate={{ scale: [1, 1.2, 1], opacity: [0.5, 0.9, 0.5] }}
        transition={{ duration: 9, repeat: Infinity, ease: "easeInOut" }}
      />
      <motion.span
        aria-hidden
        className="pointer-events-none absolute -bottom-24 h-64 w-64 rounded-full bg-white/[0.06] blur-3xl"
        style={{ insetInlineStart: "-3rem" }}
        animate={{ scale: [1.1, 0.95, 1.1], opacity: [0.4, 0.8, 0.4] }}
        transition={{ duration: 11, repeat: Infinity, ease: "easeInOut" }}
      />
      <span aria-hidden className="pointer-events-none absolute inset-0 rounded-[2rem] ring-1 ring-inset ring-white/10" />

      <div className="relative grid items-center gap-8 lg:grid-cols-[1fr_auto] lg:gap-14">
        {/* ingredients */}
        <div>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-4 sm:gap-x-4">
            {parts.map((part, i) => (
              <Fragment key={part}>
                {i > 0 && (
                  <motion.span
                    aria-hidden
                    className="font-display text-2xl text-white/30"
                    animate={{ rotate: lit(i) ? 90 : 0, color: lit(i) ? "rgba(255,255,255,0.9)" : "rgba(255,255,255,0.3)" }}
                    transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                  >
                    +
                  </motion.span>
                )}
                <motion.span
                  className="relative inline-flex items-center gap-2.5 rounded-full border px-4 py-2.5 font-display text-sm sm:text-base"
                  animate={{
                    backgroundColor: lit(i) ? "rgba(255,255,255,1)" : "rgba(255,255,255,0.04)",
                    color: lit(i) ? "#000" : "rgba(255,255,255,0.55)",
                    borderColor: lit(i) ? "rgba(255,255,255,1)" : "rgba(255,255,255,0.18)",
                    scale: step === i ? 1.08 : 1,
                    boxShadow: step === i ? "0 0 40px 4px rgba(255,255,255,0.28)" : "0 0 0 0 rgba(255,255,255,0)",
                  }}
                  transition={{ duration: 0.6, ease: [0.16, 1, 0.3, 1] }}
                >
                  <motion.span
                    aria-hidden
                    className="block h-2 w-2 rounded-full"
                    animate={{ backgroundColor: lit(i) ? "#000" : "rgba(255,255,255,0.4)", scale: step === i ? [1, 1.7, 1] : 1 }}
                    transition={{ duration: 0.7 }}
                  />
                  {part}
                </motion.span>
              </Fragment>
            ))}
          </div>

          {/* signal track */}
          <div className="relative mt-8 h-px w-full bg-white/15">
            <motion.span
              className="absolute inset-y-0 bg-white"
              style={{ insetInlineStart: 0 }}
              animate={{ width: `${progress * 100}%` }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            />
            <motion.span
              aria-hidden
              className="absolute top-1/2 -mt-1.5 h-3 w-3 rounded-full bg-white shadow-[0_0_18px_4px_rgba(255,255,255,0.6)]"
              style={{ [rtl ? "right" : "left"]: 0 }}
              animate={{ [rtl ? "right" : "left"]: `calc(${progress * 100}% - 6px)`, opacity: step === -1 ? 0 : 1 }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            />
          </div>

          <div className="mt-6 flex items-center gap-3">
            <motion.span
              aria-hidden
              className="font-display text-2xl"
              animate={{ opacity: done ? 1 : 0.3, x: done ? 0 : rtl ? 8 : -8 }}
              transition={{ duration: 0.6 }}
            >
              =
            </motion.span>
            <AnimatePresence mode="wait">
              <motion.span
                key={done ? "on" : "off"}
                initial={{ opacity: 0, y: 10, filter: "blur(6px)" }}
                animate={{ opacity: done ? 1 : 0.35, y: 0, filter: "blur(0px)" }}
                exit={{ opacity: 0, y: -10, filter: "blur(6px)" }}
                transition={{ duration: 0.5 }}
                className="font-display text-xl font-semibold sm:text-3xl"
              >
                {t.partner.equationResult}
              </motion.span>
            </AnimatePresence>
          </div>
        </div>

        {/* the mark draws itself when the equation resolves */}
        <div className="relative mx-auto h-44 w-52 sm:h-52 sm:w-60">
          <motion.span
            aria-hidden
            className="absolute inset-4 rounded-full bg-white/10 blur-2xl"
            animate={{ opacity: done ? 1 : 0.15, scale: done ? 1.1 : 0.8 }}
            transition={{ duration: 1 }}
          />
          <svg viewBox="130 130 800 590" className="relative h-full w-full" aria-hidden>
            <motion.path
              d={ICON_PATH}
              fill="rgba(255,255,255,0.07)"
              stroke="#fff"
              strokeWidth={9}
              strokeLinejoin="round"
              initial={false}
              animate={{
                pathLength: Math.max(0.04, progress),
                strokeOpacity: done ? 1 : 0.55,
                fillOpacity: done ? 1 : 0,
              }}
              transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
            />
            <motion.ellipse
              cx={ICON_DOT.cx}
              cy={ICON_DOT.cy}
              rx={ICON_DOT.rx}
              ry={ICON_DOT.ry}
              fill="#fff"
              style={{ transformOrigin: `${ICON_DOT.cx}px ${ICON_DOT.cy}px`, transformBox: "view-box" }}
              initial={false}
              animate={{ scale: done ? [0.2, 1.25, 1] : 0.2, opacity: done ? 1 : 0 }}
              transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
