"use client";

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { BlurShapes } from "../components/BlurShapes";
import { Reveal } from "../components/Reveal";
import { Kicker, PageMeta } from "../components/ui";
import { WorkImage } from "../components/WorkImage";
import { archiveWorks, works, WORK_URL } from "../data/projects";
import { useLanguage } from "../i18n/LanguageContext";

type Story = {
  title: string;
  copy: string;
  closing?: string;
  slug?: string;
  archive?: string;
  sector: string;
};

function resolve(story: Story) {
  if (story.slug) {
    const w = works.find((x) => x.slug === story.slug);
    if (w?.cover) return { cover: w.cover, url: w.caseUrl, domain: w.domain ?? "puiux.com" };
  }
  if (story.archive) {
    const a = archiveWorks.find((x) => x.titleEn === story.archive);
    if (a) return { cover: a.cover, url: WORK_URL, domain: "puiux.org" };
  }
  return { cover: "", url: WORK_URL, domain: "puiux.com" };
}

const copy = {
  ar: { chapter: "الفصل", view: "اطّلع على العمل", of: "من" },
  en: { chapter: "Chapter", view: "View the work", of: "of" },
} as const;

function Chapter({ story, i, total }: { story: Story; i: number; total: number }) {
  const { lang, dir } = useLanguage();
  const rtl = dir === "rtl";
  const c = copy[lang];
  const { cover, url, domain } = resolve(story);
  const flip = i % 2 === 1;
  const ref = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start end", "end start"] });
  const imgY = useTransform(scrollYProgress, [0, 1], ["-7%", "7%"]);
  const numY = useTransform(scrollYProgress, [0, 1], [60, -60]);
  const num = String(i + 1).padStart(2, "0");

  return (
    <div ref={ref} className="relative grid grid-cols-1 items-center gap-8 lg:grid-cols-12 lg:gap-14">
      {/* oversized chapter numeral */}
      <motion.span
        aria-hidden
        style={{ y: numY, WebkitTextStroke: "1px rgba(0,0,0,0.12)", insetInlineStart: flip ? "auto" : "-1rem", insetInlineEnd: flip ? "-1rem" : "auto" }}
        className="pointer-events-none absolute -top-16 z-0 select-none font-display text-[10rem] font-bold leading-none text-transparent sm:text-[16rem]"
        dir="ltr"
      >
        {num}
      </motion.span>

      {/* media */}
      <motion.a
        href={url}
        target="_blank"
        rel="noreferrer"
        aria-label={story.title}
        initial={{ opacity: 0, y: 60, clipPath: "inset(12% 0% 0% 0% round 28px)" }}
        whileInView={{ opacity: 1, y: 0, clipPath: "inset(0% 0% 0% 0% round 28px)" }}
        viewport={{ once: true, amount: 0.25 }}
        transition={{ duration: 1.1, ease: [0.16, 1, 0.3, 1] }}
        className={`group relative z-10 block lg:col-span-7 ${flip ? "lg:order-2" : ""}`}
      >
        <div className="overflow-hidden rounded-[1.75rem] bg-[#0b0b0b] shadow-[0_50px_100px_-50px_rgba(0,0,0,0.65)] ring-1 ring-black/10">
          <div className="flex items-center gap-2 border-b border-white/10 bg-white/[0.06] px-4 py-3 backdrop-blur" dir="ltr">
            <span className="h-2.5 w-2.5 rounded-full bg-white/30" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/20" />
            <span className="h-2.5 w-2.5 rounded-full bg-white/10" />
            <span className="mx-auto max-w-[60%] truncate rounded-full bg-white/10 px-4 py-1 text-[11px] tracking-wide text-white/60">
              {domain}
            </span>
          </div>
          <div className="relative aspect-[16/10] overflow-hidden">
            <motion.div style={{ y: imgY, scale: 1.18 }} className="absolute inset-0">
              <WorkImage
                src={cover}
                alt={story.title}
                fallbackLabel={story.title}
                className="media-zoom"
                imgClassName="transition-transform duration-[1400ms] group-hover:scale-[1.04]"
              />
            </motion.div>
            <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent opacity-70 transition-opacity duration-700 group-hover:opacity-20" />
          </div>
        </div>
      </motion.a>

      {/* text */}
      <div className={`relative z-10 lg:col-span-5 ${flip ? "lg:order-1" : ""}`}>
        <Reveal>
          <div className="flex items-center gap-4 text-[11px] font-semibold uppercase tracking-[0.3em] text-black/50">
            <motion.span
              aria-hidden
              className="block h-px w-12 bg-black"
              style={{ transformOrigin: rtl ? "right" : "left" }}
              initial={{ scaleX: 0 }}
              whileInView={{ scaleX: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
            />
            <span>
              {c.chapter} {num} / {String(total).padStart(2, "0")}
            </span>
          </div>
          <h3 className="mt-6 font-display text-4xl font-semibold leading-[1.05] tracking-tight text-black sm:text-6xl">
            {story.title}
          </h3>
          <span className="mt-5 inline-flex items-center rounded-full border border-black/15 bg-white/50 px-4 py-1.5 text-xs font-medium text-black/70 backdrop-blur">
            {story.sector}
          </span>
          <p className="mt-6 text-base leading-relaxed text-black/70 sm:text-lg">{story.copy}</p>
          {story.closing && (
            <p className="mt-4 font-display text-base font-semibold text-black sm:text-lg">{story.closing}</p>
          )}
          <a
            href={url}
            target="_blank"
            rel="noreferrer"
            className="group/link mt-8 inline-flex items-center gap-3 text-sm font-semibold text-black"
          >
            <span className="relative">
              {c.view}
              <span className="absolute -bottom-1 start-0 h-px w-full origin-left scale-x-0 bg-black transition-transform duration-500 group-hover/link:scale-x-100" />
            </span>
            <span className="flex h-9 w-9 items-center justify-center rounded-full bg-black text-white transition-transform duration-500 group-hover/link:scale-110">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="h-4 w-4" aria-hidden>
                <path d={rtl ? "M20 12H4M10 6l-6 6 6 6" : "M4 12h16M14 6l6 6-6 6"} strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </span>
          </a>
        </Reveal>
      </div>
    </div>
  );
}

export function Stories() {
  const { t } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "stories");
  const items = t.stories.items as Story[];

  return (
    <section
      id="stories"
      className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 isolate sm:px-10 lg:px-16"
    >
      <BlurShapes tone="light" seed={3} />

      <Reveal>
        <Kicker>{t.stories.kicker}</Kicker>
        <h2 className="mt-8 max-w-2xl font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
          {t.stories.heading}
        </h2>
      </Reveal>

      <div className="relative z-10 mt-20 flex flex-col gap-28 sm:gap-36">
        {items.map((story, i) => (
          <Chapter key={story.title} story={story} i={i} total={items.length} />
        ))}
      </div>

      <PageMeta index={String(idx + 1).padStart(2, "0")} label={t.sectionIndex[idx].label} />
    </section>
  );
}
