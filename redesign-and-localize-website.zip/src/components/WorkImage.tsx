"use client";

import { useState } from "react";
import { cn } from "../utils/cn";

interface WorkImageProps {
  src: string;
  srcSet?: string;
  sizes?: string;
  alt: string;
  /** text used by the elegant fallback if the remote image can't be loaded */
  fallbackLabel: string;
  accent?: string;
  className?: string;
  imgClassName?: string;
  eager?: boolean;
}

/**
 * Remote cover image with a soft skeleton while loading and a tidy
 * on-brand fallback tile (never a broken-image icon).
 */
export function WorkImage({
  src,
  srcSet,
  sizes,
  alt,
  fallbackLabel,
  accent = "#ffffff",
  className,
  imgClassName,
  eager,
}: WorkImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div
        className={cn("relative flex h-full w-full items-center justify-center overflow-hidden bg-[#0d0d10] p-6 text-center", className)}
        style={{ backgroundImage: `radial-gradient(90% 90% at 50% 120%, ${accent}55, transparent 70%)` }}
      >
        <span className="font-display text-xl font-semibold leading-snug text-white/80">{fallbackLabel}</span>
      </div>
    );
  }

  return (
    <div className={cn("relative h-full w-full overflow-hidden bg-[#111114]", className)}>
      {!loaded && <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-[#1a1a1f] to-[#0b0b0d]" />}
      <img
        src={src}
        srcSet={srcSet}
        sizes={sizes}
        alt={alt}
        loading={eager ? "eager" : "lazy"}
        decoding="async"
        referrerPolicy="no-referrer"
        onLoad={() => setLoaded(true)}
        onError={() => setFailed(true)}
        className={cn(
          "h-full w-full object-cover object-top transition-[opacity,transform] duration-[1200ms] ease-out",
          loaded ? "opacity-100" : "opacity-0",
          imgClassName
        )}
      />
    </div>
  );
}
