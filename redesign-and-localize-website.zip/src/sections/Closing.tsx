"use client";

import { useEffect, useState } from "react";
import { motion, useAnimate, useInView } from "framer-motion";
import { BlurShapes } from "../components/BlurShapes";
import { Reveal } from "../components/Reveal";
import { AccentButton, Kicker, PageMeta } from "../components/ui";
import { DigitalGlass } from "../components/glass/DigitalGlass";
import { useLanguage } from "../i18n/LanguageContext";

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

/**
 * Three statements, one after another: each is *written* onto the page (a clean wipe led by a
 * caret), rests a beat, then drifts upward and dissolves — making room for the next.
 * Finally the answer is written and stays.
 */
function ImpactSequence() {
  const { t, dir } = useLanguage();
  const rtl = dir === "rtl";
  const [scope, animate] = useAnimate();
  const inView = useInView(scope, { once: true, amount: 0.55 });
  const [active, setActive] = useState(-1);

  const hidden = rtl ? "inset(-25% 0% -25% 100%)" : "inset(-25% 100% -25% 0%)";
  const shown = "inset(-25% 0% -25% 0%)";
  const edge = rtl ? "right" : "left";

  useEffect(() => {
    if (!inView) return;
    let cancelled = false;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    const write = async (sel: string, caretSel: string, dur: number) => {
      await Promise.all([
        animate(sel, { clipPath: [hidden, shown] }, { duration: dur, ease: [0.65, 0, 0.35, 1] }),
        animate(caretSel, { [edge]: ["0%", "100%"], opacity: [1, 1] }, { duration: dur, ease: [0.65, 0, 0.35, 1] }),
      ]);
      animate(caretSel, { opacity: 0 }, { duration: 0.15 });
    };

    (async () => {
      if (reduced) {
        await animate(".imp-final-wrap", { opacity: 1 }, { duration: 0.2 });
        setActive(3);
        return;
      }
      for (let i = 0; i < t.impact.lines.length; i++) {
        if (cancelled) return;
        setActive(i);
        await animate(`.imp-line-${i}`, { opacity: 1, y: 0 }, { duration: 0.01 });
        await write(`.imp-text-${i}`, `.imp-caret-${i}`, 0.7);
        await wait(280);
        if (cancelled) return;
        // rise with a faint, fading veil until it is gone
        await animate(
          `.imp-line-${i}`,
          { y: -90, opacity: [1, 0.28, 0], filter: ["blur(0px)", "blur(1px)", "blur(5px)"] },
          { duration: 0.7, ease: [0.22, 1, 0.36, 1] }
        );
        await wait(40);
      }
      if (cancelled) return;
      setActive(3);
      await animate(".imp-final-wrap", { opacity: 1 }, { duration: 0.01 });
      await write(".imp-joiner-text", ".imp-joiner-caret", 0.6);
      await wait(100);
      await write(".imp-final-text", ".imp-final-caret", 0.7);
    })();

    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [inView]);

  const caret = (cls: string, h = "h-[78%]") => (
    <span
      aria-hidden
      className={`${cls} pointer-events-none absolute top-[11%] ${h} w-[3px] rounded-full bg-black opacity-0`}
      style={{ [edge]: "0%" }}
    />
  );

  return (
    <div ref={scope} className="relative mx-auto h-[300px] w-full max-w-5xl sm:h-[340px]">
      {t.impact.lines.map((line, i) => (
        <div
          key={line}
          className={`imp-line-${i} absolute inset-0 flex items-center justify-center text-center opacity-0`}
        >
          <span className="relative inline-block px-3">
            <span
              className={`imp-text-${i} block font-display text-4xl font-semibold leading-tight tracking-tight text-black sm:text-6xl lg:text-7xl`}
              style={{ clipPath: hidden }}
            >
              {line}
            </span>
            {caret(`imp-caret-${i}`)}
          </span>
        </div>
      ))}

      <div className="imp-final-wrap absolute inset-0 flex flex-col items-center justify-center gap-6 text-center opacity-0">
        <span className="relative inline-block px-3">
          <span
            className="imp-joiner-text block font-display text-xl text-black sm:text-3xl"
            style={{ clipPath: hidden }}
          >
            {t.impact.joiner}
          </span>
          {caret("imp-joiner-caret")}
        </span>
        <span className="relative inline-block px-3">
          <span
            className="imp-final-text block font-display text-4xl font-semibold leading-tight tracking-tight text-black sm:text-6xl lg:text-7xl"
            style={{ clipPath: hidden }}
          >
            {t.impact.final}
          </span>
          {caret("imp-final-caret")}
        </span>
      </div>

      {/* progress ticks */}
      <div className="absolute inset-x-0 -bottom-2 flex justify-center gap-2">
        {[0, 1, 2].map((i) => (
          <motion.span
            key={i}
            className="h-[3px] rounded-full bg-black"
            animate={{ width: active === i ? 36 : 10, opacity: active === i ? 1 : active > i ? 0.35 : 0.12 }}
            transition={{ duration: 0.3 }}
          />
        ))}
      </div>
    </div>
  );
}

export function Closing() {
  const { t, lang } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "contact");

  return (
    <>
      <section
        id="impact"
        className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 isolate sm:px-10 lg:px-16"
      >
        <BlurShapes tone="light" seed={2} />
        <ImpactSequence />
      </section>

      <section
        id="closing"
        className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 isolate sm:px-10 lg:px-16"
      >
        <BlurShapes tone="light" seed={3} />

        <div className="relative z-10 mx-auto grid w-full max-w-6xl grid-cols-1 items-center gap-6 lg:grid-cols-2 lg:gap-12">
          <Reveal className="order-2 lg:order-1">
            <Kicker>{t.cta.kicker}</Kicker>
            <h2 className="mt-8 font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl" dir={lang === "ar" ? "rtl" : "ltr"} style={{ textAlign: "start" }}>
              {t.cta.heading}
            </h2>
            <p className="mt-6 max-w-xl text-sm leading-relaxed text-black/65 sm:text-base">{t.cta.copy}</p>
            <div className="mt-10">
              <AccentButton href="#contact" tone="dark">
                {t.cta.button}
              </AccentButton>
            </div>
          </Reveal>

          <motion.div
            initial={{ opacity: 0, scale: 0.92 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative order-1 mx-auto aspect-[1.1/1] w-full max-w-[600px] lg:order-2"
          >
            <DigitalGlass className="absolute inset-0" />
          </motion.div>
        </div>

        <PageMeta index={String(idx).padStart(2, "0")} label={lang === "ar" ? "ختام" : "Closing"} />
      </section>
    </>
  );
}
