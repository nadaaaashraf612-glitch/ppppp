"use client";

import { Reveal } from "../components/Reveal";
import { BlurShapes } from "../components/BlurShapes";
import { GlowOrb, Kicker, PageMeta } from "../components/ui";
import { ValueArt } from "../components/ValueArt";
import { useLanguage } from "../i18n/LanguageContext";
import { cn } from "../utils/cn";

export function Values() {
  const { t } = useLanguage();
  const idx = t.sectionIndex.findIndex((s) => s.id === "values");

  return (
    <section id="values" className="relative flex min-h-screen flex-col justify-center overflow-hidden bg-[#fafaf8] px-6 py-28 sm:px-10 lg:px-16 isolate">
      <BlurShapes tone="light" seed={16} />
      <GlowOrb className="end-0 bottom-10 h-80 w-80" />

      <Reveal>
        <Kicker>{t.values.kicker}</Kicker>
        <h2 className="mt-8 max-w-2xl font-display text-5xl font-semibold leading-tight tracking-tight sm:text-6xl">
          {t.values.heading}
        </h2>
      </Reveal>

      <div className="relative z-10 mt-14 grid grid-cols-1 gap-5 md:grid-cols-2 lg:grid-cols-6">
        {t.values.items.map((item, i) => (
          <Reveal key={item.title} delay={i * 90} className={cn("min-w-0", i < 3 ? "lg:col-span-2" : "lg:col-span-3")}>
            <article className="group relative flex h-full flex-col overflow-hidden rounded-[28px] border border-black/[0.07] bg-white/70 p-3 shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_24px_60px_-34px_rgba(0,0,0,0.28)] backdrop-blur-xl transition-all duration-500 ease-out hover:-translate-y-1.5 hover:border-black/20 hover:shadow-[0_1px_0_rgba(255,255,255,0.9)_inset,0_34px_70px_-30px_rgba(0,0,0,0.36)]">
              {/* illustration stage */}
              <div className="relative overflow-hidden rounded-[20px] bg-gradient-to-b from-[#f3f3f0] to-[#ebebe7]">
                <div
                  aria-hidden
                  className="absolute inset-0 opacity-60"
                  style={{
                    backgroundImage: "radial-gradient(rgba(0,0,0,0.13) 1px, transparent 1.2px)",
                    backgroundSize: "16px 16px",
                    maskImage: "radial-gradient(70% 70% at 50% 50%, #000 20%, transparent 100%)",
                    WebkitMaskImage: "radial-gradient(70% 70% at 50% 50%, #000 20%, transparent 100%)",
                  }}
                />
                <ValueArt
                  index={i}
                  className="relative mx-auto h-44 w-full text-black transition-transform duration-700 ease-out group-hover:scale-[1.07]"
                />
                <span className="absolute start-4 top-3 font-display text-xs tabular-nums text-black/35">
                  {String(i + 1).padStart(2, "0")}
                </span>
              </div>

              {/* text */}
              <div className="flex flex-1 flex-col px-3 pb-3 pt-6">
                <div className="flex items-center gap-3">
                  <span className="h-px w-6 bg-black/40 transition-all duration-500 group-hover:w-10" />
                  <h3 className="font-display text-xl font-semibold tracking-tight sm:text-2xl">{item.title}</h3>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-black/65 sm:text-base">{item.copy}</p>
              </div>
            </article>
          </Reveal>
        ))}
      </div>

      <PageMeta index={String(idx + 1).padStart(2, "0")} label={t.sectionIndex[idx].label} />
    </section>
  );
}
