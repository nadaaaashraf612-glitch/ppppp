"use client";

import { motion } from "framer-motion";

/**
 * Five tiny monochrome illustrations — one per company value — each with a calm, looping motion.
 * All of them live in a 200 × 120 box and use currentColor so they follow the card's ink.
 */

const loop = { repeat: Infinity, ease: "easeInOut" as const };

/** Precision — a sight that hunts, then locks onto the centre. */
function PrecisionArt() {
  return (
    <>
      <circle cx="100" cy="60" r="46" fill="none" stroke="currentColor" strokeOpacity="0.14" />
      <circle cx="100" cy="60" r="30" fill="none" stroke="currentColor" strokeOpacity="0.22" />
      <motion.circle
        cx="100"
        cy="60"
        r="46"
        fill="none"
        stroke="currentColor"
        strokeOpacity="0.5"
        strokeDasharray="2 7"
        strokeLinecap="round"
        animate={{ rotate: 360 }}
        transition={{ duration: 18, repeat: Infinity, ease: "linear" }}
      />
      {/* crosshair */}
      <motion.g
        animate={{ x: [-34, 0, 0, -34], y: [18, 0, 0, 18] }}
        transition={{ duration: 3.6, times: [0, 0.35, 0.8, 1], ...loop }}
      >
        <line x1="100" y1="22" x2="100" y2="46" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        <line x1="100" y1="74" x2="100" y2="98" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        <line x1="62" y1="60" x2="86" y2="60" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        <line x1="114" y1="60" x2="138" y2="60" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      </motion.g>
      <motion.circle
        cx="100"
        cy="60"
        r="4.5"
        fill="currentColor"
        animate={{ scale: [1, 1, 1.5, 1], opacity: [0.5, 0.5, 1, 1] }}
        transition={{ duration: 3.6, times: [0, 0.35, 0.5, 1], ...loop }}
      />
    </>
  );
}

/** Uniqueness — one shape that refuses to look like the others. */
function UniquenessArt() {
  const xs = [34, 67, 133, 166];
  return (
    <>
      {xs.map((x, i) => (
        <motion.circle
          key={x}
          cx={x}
          cy="60"
          r="11"
          fill="currentColor"
          fillOpacity="0.13"
          stroke="currentColor"
          strokeOpacity="0.2"
          animate={{ scale: [1, 0.86, 1] }}
          transition={{ duration: 3, delay: i * 0.25, ...loop }}
        />
      ))}
      <motion.circle
        cx="100"
        cy="60"
        r="22"
        fill="none"
        stroke="currentColor"
        strokeOpacity="0.35"
        animate={{ scale: [0.8, 1.5], opacity: [0.7, 0] }}
        transition={{ duration: 2.4, repeat: Infinity, ease: "easeOut" }}
      />
      <motion.rect
        x="82"
        y="42"
        width="36"
        height="36"
        rx="10"
        fill="currentColor"
        animate={{ rotate: [45, 135, 135, 225], y: [0, -7, 0, -7], scale: [1, 1.08, 1, 1.08] }}
        transition={{ duration: 6, times: [0, 0.4, 0.6, 1], ...loop }}
      />
      <circle cx="100" cy="60" r="3.5" fill="#fafaf8" />
    </>
  );
}

/** Collaboration — three circles drifting together until they overlap. */
function CollaborationArt() {
  const items = [
    { x: 74, y: 52, from: [-14, 6] },
    { x: 126, y: 52, from: [14, 6] },
    { x: 100, y: 78, from: [0, -14] },
  ];
  return (
    <>
      {items.map((c, i) => (
        <motion.circle
          key={i}
          cx={c.x}
          cy={c.y}
          r="28"
          fill="currentColor"
          fillOpacity="0.09"
          stroke="currentColor"
          strokeOpacity="0.7"
          strokeWidth="1.4"
          animate={{ x: [c.from[0], 0, 0, c.from[0]], y: [c.from[1], 0, 0, c.from[1]] }}
          transition={{ duration: 4.4, times: [0, 0.45, 0.75, 1], ...loop }}
        />
      ))}
      <motion.circle
        cx="100"
        cy="62"
        r="4.5"
        fill="currentColor"
        animate={{ scale: [0, 0, 1.2, 1, 0], opacity: [0, 0, 1, 1, 0] }}
        transition={{ duration: 4.4, times: [0, 0.4, 0.55, 0.75, 1], ...loop }}
      />
    </>
  );
}

/** Continuous innovation — a loop that never stops turning, with a spark at its heart. */
function InnovationArt() {
  return (
    <>
      <circle cx="100" cy="60" r="38" fill="none" stroke="currentColor" strokeOpacity="0.12" />
      <motion.g
        animate={{ rotate: 360 }}
        transition={{ duration: 9, repeat: Infinity, ease: "linear" }}
      >
        <path d="M 100 22 A 38 38 0 0 1 138 60" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
        <path d="M 131 52 L 138 61 L 146 52" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M 100 98 A 38 38 0 0 1 62 60" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
        <path d="M 69 68 L 62 59 L 54 68" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" />
      </motion.g>
      <motion.path
        d="M 100 46 C 101.5 55 105 58.5 114 60 C 105 61.5 101.5 65 100 74 C 98.5 65 95 61.5 86 60 C 95 58.5 98.5 55 100 46 Z"
        fill="currentColor"
        animate={{ scale: [0.75, 1.15, 0.75], rotate: [0, 90, 180] }}
        transition={{ duration: 3.2, ...loop }}
      />
    </>
  );
}

/** Ownership — a shield that draws itself and seals with a check. */
function OwnershipArt() {
  return (
    <>
      <motion.circle
        cx="100"
        cy="60"
        r="30"
        fill="none"
        stroke="currentColor"
        strokeOpacity="0.3"
        animate={{ scale: [0.9, 1.7], opacity: [0.6, 0] }}
        transition={{ duration: 2.8, repeat: Infinity, ease: "easeOut" }}
      />
      <motion.path
        d="M 100 18 L 134 30 V 60 C 134 82 118 96 100 104 C 82 96 66 82 66 60 V 30 Z"
        fill="currentColor"
        fillOpacity="0.07"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: [0, 1, 1, 1] }}
        transition={{ duration: 4, times: [0, 0.4, 0.9, 1], ...loop, repeatDelay: 0.4 }}
      />
      <motion.path
        d="M 85 62 L 96 73 L 117 49"
        fill="none"
        stroke="currentColor"
        strokeWidth="3.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: [0, 0, 1, 1] }}
        transition={{ duration: 4, times: [0, 0.35, 0.55, 1], ...loop, repeatDelay: 0.4 }}
      />
    </>
  );
}

const arts = [PrecisionArt, UniquenessArt, CollaborationArt, InnovationArt, OwnershipArt];

export function ValueArt({ index, className }: { index: number; className?: string }) {
  const Art = arts[index % arts.length];
  return (
    <svg viewBox="0 0 200 120" className={className} aria-hidden>
      <Art />
    </svg>
  );
}
