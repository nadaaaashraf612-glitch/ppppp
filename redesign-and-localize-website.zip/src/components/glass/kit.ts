import * as THREE from "three";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";

export type Tone = "dark" | "light";

/** The PUIUX mark: a "U" cradle with two round shoulders + a dot held inside. */
export const ICON_PATH =
  "M528 682C400 682 310 610 275 500C258 445 250 410 205 355C175 318 165 295 165 265C165 205 210 165 265 165C325 165 367 220 367 275C367 330 345 355 350 405C355 470 375 520 410 550C445 580 490 590 528 590C566 590 611 580 646 550C681 520 701 470 706 405C711 355 689 330 689 275C689 220 731 165 791 165C846 165 892 205 892 265C892 295 882 318 851 355C806 410 798 445 781 500C746 610 656 682 528 682Z";
export const ICON_DOT = { cx: 528, cy: 441, rx: 69, ry: 76 };

export const easeOutExpo = (x: number) => (x >= 1 ? 1 : 1 - Math.pow(2, -10 * x));
export const easeInOut = (x: number) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);

/**
 * Neutral studio backdrop. Black glass only reads as glass when there is
 * something behind it to bend, so we paint soft vertical light bands that the
 * glass refracts. Strictly monochrome.
 */
export function makeBackdrop(tone: Tone) {
  const S = 1024;
  const c = document.createElement("canvas");
  c.width = S;
  c.height = S;
  const g = c.getContext("2d")!;
  const dark = tone === "dark";

  g.fillStyle = dark ? "#000000" : "#fafaf8";
  g.fillRect(0, 0, S, S);

  const glow = g.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S * 0.56);
  if (dark) {
    glow.addColorStop(0, "rgba(255,255,255,0.34)");
    glow.addColorStop(0.55, "rgba(255,255,255,0.1)");
    glow.addColorStop(1, "rgba(255,255,255,0)");
  } else {
    glow.addColorStop(0, "rgba(255,255,255,1)");
    glow.addColorStop(1, "rgba(236,236,232,0)");
  }
  g.fillStyle = glow;
  g.fillRect(0, 0, S, S);

  // soft vertical strips: [x, width, strength]
  const bands: [number, number, number][] = [
    [70, 64, 0.1],
    [190, 16, 0.26],
    [300, 110, 0.07],
    [430, 22, 0.2],
    [520, 70, 0.12],
    [640, 12, 0.3],
    [740, 120, 0.08],
    [880, 26, 0.18],
    [960, 50, 0.1],
  ];
  for (const [x, w, a] of bands) {
    const lg = g.createLinearGradient(x - w, 0, x + w, 0);
    const col = dark ? "255,255,255" : "18,18,18";
    const k = dark ? a : a * 0.55;
    lg.addColorStop(0, `rgba(${col},0)`);
    lg.addColorStop(0.5, `rgba(${col},${k})`);
    lg.addColorStop(1, `rgba(${col},0)`);
    g.fillStyle = lg;
    g.fillRect(x - w, 0, w * 2, S);
  }

  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

export interface GlassOpts {
  /** how much light survives passing through (0x000000 = ink, 0x404040 = smoke) */
  smoke?: number;
  /** world-units over which the smoke colour fully applies */
  distance?: number;
  roughness?: number;
  tint?: number;
  envMapIntensity?: number;
  thickness?: number;
}

/** Transparent black glass. */
export function glassMaterial(o: GlassOpts = {}) {
  return new THREE.MeshPhysicalMaterial({
    color: o.tint ?? 0x4a4a4a,
    metalness: 0,
    roughness: o.roughness ?? 0.04,
    transmission: 1,
    thickness: o.thickness ?? 1,
    ior: 1.52,
    attenuationColor: new THREE.Color(o.smoke ?? 0x1e1e1e),
    attenuationDistance: o.distance ?? 1,
    clearcoat: 1,
    clearcoatRoughness: 0.02,
    specularIntensity: 1,
    envMapIntensity: o.envMapIntensity ?? 2.1,
    side: THREE.FrontSide,
  });
}

export interface StageCtx {
  scene: THREE.Scene;
  camera: THREE.PerspectiveCamera;
  renderer: THREE.WebGLRenderer;
}

export interface SceneApi {
  update(t: number, pointer: { x: number; y: number }, intro: number): void;
  dispose(): void;
}

export interface StageOpts {
  tone: Tone;
  /** world-space rectangle that must stay fully visible */
  frame: { w: number; h: number };
  fov?: number;
  /** camera elevation (radians) – used by the pixel-ripple scene */
  tilt?: number;
  introSeconds?: number;
  setup: (ctx: StageCtx) => SceneApi;
}

/** Mounts a self-contained, pause-when-offscreen WebGL stage. Returns cleanup, or null if WebGL is unavailable. */
export function mountStage(host: HTMLElement, opts: StageOpts): (() => void) | null {
  let renderer: THREE.WebGLRenderer;
  try {
    renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: "high-performance" });
  } catch {
    return null;
  }

  const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const coarse = window.matchMedia("(pointer: coarse)").matches;

  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.75));
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = opts.tone === "dark" ? 1.05 : 0.95;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  const canvas = renderer.domElement;
  canvas.style.width = "100%";
  canvas.style.height = "100%";
  canvas.style.display = "block";
  host.appendChild(canvas);

  const scene = new THREE.Scene();
  const backdrop = makeBackdrop(opts.tone);
  scene.background = backdrop;

  const pmrem = new THREE.PMREMGenerator(renderer);
  const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
  scene.environment = envTex;

  const fov = opts.fov ?? 32;
  const camera = new THREE.PerspectiveCamera(fov, 1, 0.1, 100);

  const key = new THREE.DirectionalLight(0xffffff, 2.2);
  key.position.set(3, 4, 5);
  const rim = new THREE.DirectionalLight(0xffffff, 1.8);
  rim.position.set(-5, 1, -3);
  scene.add(key, rim);

  const api = opts.setup({ scene, camera, renderer });

  const resize = () => {
    const w = host.clientWidth || 1;
    const h = host.clientHeight || 1;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    const needed = Math.max(opts.frame.h, opts.frame.w / camera.aspect);
    const z = needed / 2 / Math.tan((fov * Math.PI) / 360);
    const tilt = opts.tilt ?? 0;
    camera.position.set(0, Math.sin(tilt) * z, Math.cos(tilt) * z);
    camera.lookAt(0, 0, 0);
    camera.updateProjectionMatrix();
  };
  resize();
  const ro = new ResizeObserver(resize);
  ro.observe(host);

  const target = { x: 0, y: 0 };
  const cur = { x: 0, y: 0 };
  const onMove = (e: PointerEvent) => {
    target.x = (e.clientX / window.innerWidth) * 2 - 1;
    target.y = (e.clientY / window.innerHeight) * 2 - 1;
  };
  if (!coarse && !reduced) window.addEventListener("pointermove", onMove, { passive: true });

  let visible = true;
  const io = new IntersectionObserver(([en]) => (visible = en.isIntersecting), { threshold: 0 });
  io.observe(host);

  const clock = new THREE.Clock();
  let raf = 0;
  let t = reduced ? 4 : 0;
  const introSeconds = opts.introSeconds ?? 2.4;
  const render = () => {
    raf = requestAnimationFrame(render);
    if (!visible) {
      clock.getDelta();
      return;
    }
    const dt = Math.min(clock.getDelta(), 0.05);
    t += reduced ? 0 : dt;
    cur.x += (target.x - cur.x) * 0.06;
    cur.y += (target.y - cur.y) * 0.06;
    const intro = easeOutExpo(Math.min(t / introSeconds, 1));
    key.position.x = Math.cos(t * 0.6) * 4;
    key.position.y = 3 + Math.sin(t * 0.45) * 1.2;
    api.update(t, cur, intro);
    renderer.render(scene, camera);
  };
  render();

  return () => {
    cancelAnimationFrame(raf);
    ro.disconnect();
    io.disconnect();
    window.removeEventListener("pointermove", onMove);
    api.dispose();
    backdrop.dispose();
    envTex.dispose();
    pmrem.dispose();
    renderer.dispose();
    if (canvas.parentNode === host) host.removeChild(canvas);
  };
}
