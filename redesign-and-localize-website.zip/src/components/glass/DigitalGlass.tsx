"use client";

import { memo } from "react";
import * as THREE from "three";
import { RoundedBoxGeometry } from "three/addons/geometries/RoundedBoxGeometry.js";
import { GlassCanvas } from "./GlassCanvas";
import { glassMaterial, type StageOpts } from "./kit";
import { buildLogoGeometry } from "./logoGeometry";

/**
 * "Make it digital" — the whole PUIUX mark (the cradle and the idea inside it) floats above a
 * small bed of glass pixels. As the idea rocks gently in its cradle, the pixels beneath rise in a
 * slow ripple: analog → digital. Kept deliberately quiet: one mark, nine pixels.
 */
const N = 3;
const GAP = 0.5;
const LOGO_W = 1.75;

const opts: StageOpts = {
  tone: "light",
  frame: { w: 4.0, h: 3.5 },
  tilt: 0.3,
  introSeconds: 2,
  setup({ scene }) {
    const smoked = glassMaterial({ smoke: 0x2e2e2e, distance: 1.0, thickness: 0.45, tint: 0x6e6e6e, envMapIntensity: 1.9 });
    const logoSmoke = glassMaterial({ smoke: 0x2a2a2a, distance: 1.2, thickness: 130, tint: 0x6a6a6a, envMapIntensity: 2.1 });
    const ink = glassMaterial({ smoke: 0x181818, distance: 0.7, thickness: 140, tint: 0x4c4c4c, envMapIntensity: 2.3 });

    const group = new THREE.Group();

    // ── pixel bed ─────────────────────────────────────────────
    const cubeGeo = new RoundedBoxGeometry(0.32, 1, 0.32, 5, 0.07);
    const cubes: { mesh: THREE.Mesh; d: number }[] = [];
    const c = (N - 1) / 2;
    for (let i = 0; i < N; i++) {
      for (let j = 0; j < N; j++) {
        const mesh = new THREE.Mesh(cubeGeo, smoked);
        mesh.position.set((i - c) * GAP, 0, (j - c) * GAP);
        group.add(mesh);
        cubes.push({ mesh, d: Math.hypot(i - c, j - c) });
      }
    }

    // ── the mark ──────────────────────────────────────────────
    const { body, dot, width } = buildLogoGeometry();
    const unit = LOGO_W / width;
    const mark = new THREE.Group();
    const bodyMesh = new THREE.Mesh(body, logoSmoke);
    const dotMesh = new THREE.Mesh(dot, ink);
    mark.add(bodyMesh, dotMesh);
    mark.scale.setScalar(unit);
    mark.position.y = 1.35;
    group.add(mark);

    group.position.y = -0.85;
    scene.add(group);

    return {
      update(t, cur, intro) {
        group.rotation.y = Math.sin(t * 0.5) * 0.5 + (1 - intro) * 2.2 + cur.x * 0.35;
        group.rotation.x = cur.y * 0.06;
        group.scale.setScalar(0.7 + 0.3 * intro);

        // the mark floats; the dot rocks inside its cradle
        mark.position.y = 1.35 + Math.sin(t * 1.1) * 0.06;
        dotMesh.position.y = Math.sin(t * 1.6) * 24;

        for (const { mesh, d } of cubes) {
          const wave = Math.max(0, Math.sin(d * 1.9 - t * 1.7));
          const h = 0.1 + wave * wave * 0.34 * intro;
          mesh.scale.y = h;
          mesh.position.y = h / 2;
        }
      },
      dispose() {
        cubeGeo.dispose();
        body.dispose();
        dot.dispose();
        smoked.dispose();
        logoSmoke.dispose();
        ink.dispose();
      },
    };
  },
};

function DigitalGlassBase({ className }: { className?: string }) {
  return <GlassCanvas className={className} opts={opts} feather={64} />;
}

export const DigitalGlass = memo(DigitalGlassBase);
