"use client";

import { useId } from "react";
import { motion } from "framer-motion";

/**
 * Exact vector geometry of the PUIUX brand icon (same path + ellipse used in
 * /public/images/puiux-logo-*.svg). The brand mark itself is never altered —
 * it is only used as the hero of this illustration.
 */
const ICON_PATH =
  "M528 682C400 682 310 610 275 500C258 445 250 410 205 355C175 318 165 295 165 265C165 205 210 165 265 165C325 165 367 220 367 275C367 330 345 355 350 405C355 470 375 520 410 550C445 580 490 590 528 590C566 590 611 580 646 550C681 520 701 470 706 405C711 355 689 330 689 275C689 220 731 165 791 165C846 165 892 205 892 265C892 295 882 318 851 355C806 410 798 445 781 500C746 610 656 682 528 682Z";
const DOT = { cx: 528, cy: 441, rx: 69, ry: 76 };

/** Tiny, static, crisp version of the mark (used for the orbiting glass chips). */
function MarkGlyph({ className }: { className?: string }) {
  return (
    <svg viewBox="160 160 737 527" className={className} aria-hidden>
      <g fill="#fff">
        <path d={ICON_PATH} />
        <ellipse {...DOT} />
      </g>
    </svg>
  );
}

const TICKS = Array.from({ length: 120 }, (_, i) => i);

interface Props {
  className?: string;
  /** number of glass logo chips orbiting the medallion */
  chips?: number;
  /** show the circular engraved caption */
  caption?: boolean;
}

export function LogoIllustration({ className, chips = 0, caption = true }: Props) {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, "");
  const metal = `metal${uid}`;
  const arc = `arc${uid}`;
  const path = `circ${uid}`;
  const halo = `halo${uid}`;

  // Icon is 727 x 517 in its own coordinate system → fit ~132 units wide in 400-box
  const s = 0.185;
  const tx = 200 - 528.5 * s;
  const ty = 200 - 423.5 * s;

  const chipAngles = [0, 120, 240, 60].slice(0, chips);

  return (
    <div className={className} aria-hidden>
      <div className="relative h-full w-full">
        {/* ── Ambient aura ───────────────────────────────────────── */}
        <motion.div
          className="absolute inset-[8%] rounded-full"
          style={{
            background:
              "radial-gradient(circle, rgba(255,255,255,0.20) 0%, rgba(255,255,255,0.06) 38%, transparent 68%)",
          }}
          animate={{ scale: [0.92, 1.08, 0.92], opacity: [0.55, 1, 0.55] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
        />

        {/* ── Echo ripples: the brand mark radiating outward ─────── */}
        {[0, 1, 2].map((i) => (
          <motion.svg
            key={i}
            viewBox="0 0 400 400"
            className="absolute inset-0 h-full w-full"
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: [0.7, 1.55], opacity: [0, 0.38, 0] }}
            transition={{ duration: 7.5, repeat: Infinity, ease: "easeOut", delay: i * 2.5 }}
          >
            <g transform={`translate(${tx} ${ty}) scale(${s})`}>
              <path
                d={ICON_PATH}
                fill="none"
                stroke="#fff"
                strokeWidth={1.4}
                vectorEffect="non-scaling-stroke"
              />
            </g>
          </motion.svg>
        ))}

        {/* ── Outer engraved dial (ticks + circular caption) ──────── */}
        <motion.svg
          viewBox="0 0 400 400"
          className="absolute inset-0 h-full w-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 90, repeat: Infinity, ease: "linear" }}
        >
          <circle cx="200" cy="200" r="196" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="0.6" />
          {TICKS.map((i) => {
            const a = (i / TICKS.length) * Math.PI * 2;
            const long = i % 10 === 0;
            const mid = i % 5 === 0;
            const r1 = 196;
            const r2 = long ? 182 : mid ? 187 : 191;
            return (
              <line
                key={i}
                x1={200 + Math.cos(a) * r1}
                y1={200 + Math.sin(a) * r1}
                x2={200 + Math.cos(a) * r2}
                y2={200 + Math.sin(a) * r2}
                stroke={long ? "rgba(255,255,255,0.7)" : "rgba(255,255,255,0.28)"}
                strokeWidth={long ? 1.1 : 0.6}
              />
            );
          })}
        </motion.svg>

        {caption && (
          <motion.svg
            viewBox="0 0 400 400"
            className="absolute inset-0 h-full w-full"
            animate={{ rotate: -360 }}
            transition={{ duration: 70, repeat: Infinity, ease: "linear" }}
          >
            <defs>
              <path id={path} d="M 200 200 m -166 0 a 166 166 0 1 1 332 0 a 166 166 0 1 1 -332 0" />
            </defs>
            <text
              fill="rgba(255,255,255,0.5)"
              fontSize="8.5"
              fontWeight="600"
              
            >
              <textPath href={`#${path}`} textLength="1038" lengthAdjust="spacing">
                PUIUX · DIGITAL EXPERIENCES · UI/UX · WEB · MOBILE · BRANDING · PUIUX · CRAFTED WITH PURPOSE ·
              </textPath>
            </text>
          </motion.svg>
        )}

        {/* ── Dotted inner ring (counter-rotating) ────────────────── */}
        <motion.svg
          viewBox="0 0 400 400"
          className="absolute inset-0 h-full w-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 120, repeat: Infinity, ease: "linear" }}
        >
          <circle
            cx="200"
            cy="200"
            r="146"
            fill="none"
            stroke="rgba(255,255,255,0.22)"
            strokeWidth="1"
            strokeDasharray="1.5 7"
            strokeLinecap="round"
          />
        </motion.svg>

        {/* ── Light-sweep arcs ────────────────────────────────────── */}
        <motion.svg
          viewBox="0 0 400 400"
          className="absolute inset-0 h-full w-full"
          animate={{ rotate: 360 }}
          transition={{ duration: 9, repeat: Infinity, ease: "linear" }}
        >
          <defs>
            <linearGradient id={arc} x1="0" y1="0" x2="1" y2="0">
              <stop offset="0" stopColor="#fff" stopOpacity="0" />
              <stop offset="1" stopColor="#fff" stopOpacity="0.95" />
            </linearGradient>
          </defs>
          <circle
            cx="200"
            cy="200"
            r="130"
            fill="none"
            stroke={`url(#${arc})`}
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeDasharray="230 587"
          />
        </motion.svg>
        <motion.svg
          viewBox="0 0 400 400"
          className="absolute inset-0 h-full w-full"
          animate={{ rotate: -360 }}
          transition={{ duration: 16, repeat: Infinity, ease: "linear" }}
        >
          <circle
            cx="200"
            cy="200"
            r="154"
            fill="none"
            stroke={`url(#${arc})`}
            strokeWidth="1"
            strokeLinecap="round"
            strokeDasharray="150 818"
            opacity="0.7"
          />
        </motion.svg>

        {/* ── Orbiting light nodes ────────────────────────────────── */}
        {[
          { inset: "2%", dur: 26, size: 7, rev: false, start: 20 },
          { inset: "12.5%", dur: 18, size: 5, rev: true, start: 200 },
          { inset: "19%", dur: 12, size: 6, rev: false, start: 110 },
        ].map((o, i) => (
          <div key={i} className="absolute" style={{ inset: o.inset, transform: `rotate(${o.start}deg)` }}>
            <motion.div
              className="h-full w-full"
              animate={{ rotate: o.rev ? -360 : 360 }}
              transition={{ duration: o.dur, repeat: Infinity, ease: "linear" }}
            >
              <span
                className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 rounded-full bg-white"
                style={{
                  width: o.size,
                  height: o.size,
                  boxShadow: "0 0 14px 3px rgba(255,255,255,0.45)",
                }}
              />
            </motion.div>
          </div>
        ))}

        {/* ── Orbiting glass logo chips ───────────────────────────── */}
        {chipAngles.map((angle, i) => (
          <div key={i} className="absolute inset-[2%]" style={{ transform: `rotate(${angle}deg)` }}>
            <motion.div
              className="h-full w-full"
              animate={{ rotate: 360 }}
              transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
            >
              <div className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2">
                <div style={{ transform: `rotate(${-angle}deg)` }}>
                <motion.div
                  animate={{ rotate: -360 }}
                  transition={{ duration: 40, repeat: Infinity, ease: "linear" }}
                >
                  <div
                    className="flex items-center justify-center rounded-xl border border-white/20 bg-white/[0.07] backdrop-blur-md"
                    style={{
                      width: 34,
                      height: 34,
                      boxShadow: "0 8px 24px -8px rgba(0,0,0,0.8), inset 0 1px 0 rgba(255,255,255,0.25)",
                    }}
                  >
                    <MarkGlyph className="h-[17px] w-auto opacity-90" />
                  </div>
                </motion.div>
                </div>
              </div>
            </motion.div>
          </div>
        ))}

        {/* ── Central glass medallion ─────────────────────────────── */}
        <motion.svg
          viewBox="0 0 400 400"
          className="absolute inset-0 h-full w-full"
          animate={{ y: [-3, 5, -3] }}
          transition={{ duration: 7, repeat: Infinity, ease: "easeInOut" }}
          style={{ overflow: "visible" }}
        >
          <defs>
            <radialGradient id={`disc${uid}`} cx="35%" cy="25%" r="90%">
              <stop offset="0" stopColor="#fff" stopOpacity="0.20" />
              <stop offset="0.5" stopColor="#fff" stopOpacity="0.04" />
              <stop offset="1" stopColor="#000" stopOpacity="0.55" />
            </radialGradient>
            <linearGradient id={metal} gradientUnits="userSpaceOnUse" x1="165" y1="165" x2="892" y2="682">
              <stop offset="0" stopColor="#ffffff" />
              <stop offset="0.45" stopColor="#c9c9cc" />
              <stop offset="0.7" stopColor="#ffffff" />
              <stop offset="1" stopColor="#9a9aa0" />
              <animate attributeName="x1" values="-300;700;-300" dur="8s" repeatCount="indefinite" />
              <animate attributeName="x2" values="420;1420;420" dur="8s" repeatCount="indefinite" />
            </linearGradient>
            <radialGradient id={halo}>
              <stop offset="0" stopColor="#fff" stopOpacity="0.55" />
              <stop offset="1" stopColor="#fff" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* disc */}
          <circle cx="200" cy="200" r="104" fill={`url(#disc${uid})`} stroke="rgba(255,255,255,0.22)" strokeWidth="0.8" />
          <circle cx="200" cy="200" r="97" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="0.6" />
          <path
            d="M 112 160 A 104 104 0 0 1 250 108"
            fill="none"
            stroke="rgba(255,255,255,0.55)"
            strokeWidth="1"
            strokeLinecap="round"
            opacity="0.7"
          />

          <g transform={`translate(${tx} ${ty}) scale(${s})`}>
            {/* ghost outline echo, offset */}
            <path
              d={ICON_PATH}
              transform="translate(22 26)"
              fill="none"
              stroke="rgba(255,255,255,0.22)"
              strokeWidth="5"
            />
            {/* soft glow behind the mark */}
            <path d={ICON_PATH} fill="#fff" opacity="0.18" style={{ filter: "blur(14px)" }} />
            {/* the mark */}
            <path d={ICON_PATH} fill={`url(#${metal})`} />

            {/* the "person": breathing halo + gently bobbing dot */}
            <motion.circle
              cx={DOT.cx}
              cy={DOT.cy}
              r={80}
              fill={`url(#${halo})`}
              animate={{ scale: [0.7, 1.9], opacity: [0.8, 0] }}
              transition={{ duration: 3.2, repeat: Infinity, ease: "easeOut" }}
              style={{ transformBox: "fill-box", transformOrigin: "center" }}
            />
            <motion.ellipse
              cx={DOT.cx}
              rx={DOT.rx}
              ry={DOT.ry}
              fill="#fff"
              animate={{ cy: [DOT.cy - 10, DOT.cy + 14, DOT.cy - 10] }}
              transition={{ duration: 4.2, repeat: Infinity, ease: "easeInOut" }}
              style={{ filter: "drop-shadow(0 0 16px rgba(255,255,255,0.8))" }}
            />
          </g>
        </motion.svg>
      </div>
    </div>
  );
}
